-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 24, 2021 at 12:11 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fudbalski_klub`
--

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `komentaris`
--

CREATE TABLE `komentaris` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `products_id` int(11) NOT NULL,
  `komentar` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `komentaris`
--

INSERT INTO `komentaris` (`id`, `user_id`, `products_id`, `komentar`, `created_at`, `updated_at`) VALUES
(1, 3, 1, 'Super izgleda', '2021-07-23 19:15:31', '2021-07-23 19:15:31'),
(2, 3, 3, 'Lep dres', '2021-07-23 19:16:20', '2021-07-23 19:16:20'),
(3, 3, 2, 'OK', '2021-07-23 19:16:34', '2021-07-23 19:16:34'),
(4, 3, 9, 'Dobreee', '2021-07-23 19:16:47', '2021-07-23 19:16:47'),
(5, 3, 7, 'Izgleda super', '2021-07-23 19:17:06', '2021-07-23 19:17:06'),
(6, 3, 15, 'LOS izgled na slici', '2021-07-23 19:18:57', '2021-07-23 19:18:57'),
(7, 3, 14, 'blaaaablaa', '2021-07-23 19:19:24', '2021-07-23 19:19:24'),
(8, 4, 1, 'dobar', '2021-07-23 19:21:23', '2021-07-23 19:21:23'),
(9, 4, 1, 'Kupio sam ga, super je, svakom bi preporucio ko navija za Mancester...', '2021-07-23 19:22:11', '2021-07-23 19:22:11'),
(10, 4, 4, 'Dobar', '2021-07-23 19:22:44', '2021-07-23 19:22:44'),
(11, 4, 13, 'Super dres, preporucujem svima', '2021-07-23 19:23:12', '2021-07-23 19:23:12'),
(12, 4, 5, '...........', '2021-07-23 19:25:02', '2021-07-23 19:25:02'),
(13, 4, 6, 'lep dizajn', '2021-07-23 19:25:20', '2021-07-23 19:25:20'),
(14, 4, 8, 'super su...', '2021-07-23 19:25:32', '2021-07-23 19:25:32'),
(15, 5, 10, 'super....................', '2021-07-23 19:26:21', '2021-07-23 19:26:21'),
(16, 5, 1, 'bas dobar dres', '2021-07-23 19:26:32', '2021-07-23 19:26:32'),
(17, 5, 2, 'okej', '2021-07-23 19:27:01', '2021-07-23 19:27:01'),
(18, 5, 14, 'aasdada', '2021-07-23 19:27:28', '2021-07-23 19:27:28'),
(19, 5, 4, 'asdasdad', '2021-07-23 19:27:35', '2021-07-23 19:27:35'),
(20, 5, 2, '............', '2021-07-23 19:27:41', '2021-07-23 19:27:41'),
(21, 5, 3, 'odlican', '2021-07-23 19:28:02', '2021-07-23 19:28:02'),
(22, 5, 6, 'Nemam komentar', '2021-07-23 19:28:10', '2021-07-23 19:28:10'),
(23, 6, 14, 'saverseno', '2021-07-23 19:29:38', '2021-07-23 19:29:38'),
(24, 6, 6, 'prelepa lopta', '2021-07-23 19:29:54', '2021-07-23 19:29:54'),
(25, 6, 10, 'asdads', '2021-07-23 19:30:38', '2021-07-23 19:30:38'),
(26, 6, 15, 'los kvalitet slike..........', '2021-07-23 19:31:10', '2021-07-23 19:31:10'),
(27, 6, 5, '..', '2021-07-23 19:31:27', '2021-07-23 19:31:27'),
(28, 6, 8, 'super', '2021-07-23 19:31:46', '2021-07-23 19:31:46');

-- --------------------------------------------------------

--
-- Table structure for table `korpas`
--

CREATE TABLE `korpas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `products_id` int(11) NOT NULL,
  `kolicina` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `korpas`
--

INSERT INTO `korpas` (`id`, `user_id`, `products_id`, `kolicina`, `created_at`, `updated_at`) VALUES
(1, 3, 1, 1, '2021-07-23 19:15:17', '2021-07-23 19:15:17'),
(2, 3, 3, 1, '2021-07-23 19:16:25', '2021-07-23 19:16:25'),
(3, 3, 5, 1, '2021-07-23 19:16:28', '2021-07-23 19:16:28'),
(5, 3, 15, 1, '2021-07-23 19:19:02', '2021-07-23 19:19:02'),
(6, 4, 1, 1, '2021-07-23 19:22:16', '2021-07-23 19:22:16'),
(7, 4, 8, 1, '2021-07-23 19:22:21', '2021-07-23 19:22:21'),
(8, 4, 7, 1, '2021-07-23 19:22:23', '2021-07-23 19:22:23'),
(9, 4, 4, 1, '2021-07-23 19:22:46', '2021-07-23 19:22:46'),
(10, 4, 6, 1, '2021-07-23 19:22:49', '2021-07-23 19:22:49'),
(11, 4, 13, 1, '2021-07-23 19:22:54', '2021-07-23 19:22:54'),
(12, 5, 1, 1, '2021-07-23 19:26:07', '2021-07-23 19:26:07'),
(13, 5, 5, 1, '2021-07-23 19:26:08', '2021-07-23 19:26:08'),
(14, 5, 12, 1, '2021-07-23 19:26:11', '2021-07-23 19:26:11'),
(15, 5, 15, 1, '2021-07-23 19:26:13', '2021-07-23 19:26:13'),
(16, 5, 10, 1, '2021-07-23 19:26:15', '2021-07-23 19:26:15'),
(17, 5, 1, 1, '2021-07-23 19:26:35', '2021-07-23 19:26:35'),
(18, 6, 2, 1, '2021-07-23 19:29:10', '2021-07-23 19:29:10'),
(20, 6, 8, 1, '2021-07-23 19:29:14', '2021-07-23 19:29:14'),
(21, 6, 10, 1, '2021-07-23 19:30:35', '2021-07-23 19:30:35'),
(22, 6, 9, 1, '2021-07-23 19:30:46', '2021-07-23 19:30:46');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(40, '2014_10_12_000000_create_users_table', 1),
(41, '2014_10_12_100000_create_password_resets_table', 1),
(42, '2014_10_12_200000_add_two_factor_columns_to_users_table', 1),
(43, '2019_08_19_000000_create_failed_jobs_table', 1),
(44, '2021_07_11_233000_create_products_table', 1),
(45, '2021_07_13_161201_create_korpas_table', 1),
(46, '2021_07_13_195604_create_narudzbinas_table', 1),
(47, '2021_07_15_124920_create_komentaris_table', 1),
(48, '2021_07_21_170111_create_porukas_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `narudzbinas`
--

CREATE TABLE `narudzbinas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `products_id` int(11) NOT NULL,
  `kolicina` int(11) NOT NULL,
  `cena` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `narudzbinas`
--

INSERT INTO `narudzbinas` (`id`, `user_id`, `products_id`, `kolicina`, `cena`, `created_at`, `updated_at`) VALUES
(1, 3, 1, 1, 4899, '2021-07-23 19:15:54', '2021-07-23 19:15:54'),
(2, 3, 7, 1, 2199, '2021-07-23 19:17:12', '2021-07-23 19:17:12'),
(3, 3, 3, 1, 3999, '2021-07-23 19:17:50', '2021-07-23 19:17:50'),
(4, 3, 1, 1, 4899, '2021-07-23 19:17:51', '2021-07-23 19:17:51'),
(5, 3, 5, 1, 2790, '2021-07-23 19:17:53', '2021-07-23 19:17:53'),
(6, 4, 4, 1, 489, '2021-07-23 19:23:17', '2021-07-23 19:23:17'),
(7, 4, 8, 1, 7890, '2021-07-23 19:23:19', '2021-07-23 19:23:19'),
(8, 4, 1, 1, 4899, '2021-07-23 19:23:19', '2021-07-23 19:23:19'),
(9, 4, 13, 1, 2000, '2021-07-23 19:23:20', '2021-07-23 19:23:20'),
(10, 4, 6, 1, 8000, '2021-07-23 19:23:21', '2021-07-23 19:23:21'),
(11, 5, 5, 1, 2790, '2021-07-23 19:27:05', '2021-07-23 19:27:05'),
(12, 5, 12, 1, 13463, '2021-07-23 19:27:06', '2021-07-23 19:27:06'),
(13, 5, 10, 1, 8945, '2021-07-23 19:27:08', '2021-07-23 19:27:08'),
(14, 5, 1, 1, 4899, '2021-07-23 19:27:09', '2021-07-23 19:27:09'),
(15, 6, 2, 1, 3999, '2021-07-23 19:29:17', '2021-07-23 19:29:17'),
(16, 6, 1, 1, 4899, '2021-07-23 19:29:18', '2021-07-23 19:29:18'),
(17, 6, 8, 1, 7890, '2021-07-23 19:29:19', '2021-07-23 19:29:19'),
(18, 6, 9, 1, 26399, '2021-07-23 19:30:48', '2021-07-23 19:30:48'),
(19, 6, 10, 1, 8945, '2021-07-23 19:30:49', '2021-07-23 19:30:49');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `porukas`
--

CREATE TABLE `porukas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ime` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefon` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `poruka` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `porukas`
--

INSERT INTO `porukas` (`id`, `ime`, `email`, `telefon`, `subject`, `poruka`, `created_at`, `updated_at`) VALUES
(1, 'asd', 'dusko@dusko.rs', '0102113112', 'Primedba', 'blablabla', '2021-07-23 19:08:14', '2021-07-23 19:08:14'),
(2, 'asd', 'asd@asd.rs', '13123', 'Poruka', 'poruka................................', '2021-07-23 19:09:33', '2021-07-23 19:09:33'),
(4, 'Marko', 'marko@marko.rs', '231123412', 'Primedba', 'Imam primedbu', '2021-07-23 19:10:59', '2021-07-23 19:10:59'),
(5, 'Petar', 'petar@petar.rs', '213412312', 'ok', 'poruka....', '2021-07-23 19:11:23', '2021-07-23 19:11:23'),
(6, 'Dusko', 'dusko@dusko.rs', '0312310231', 'Primedba', 'blablabla', '2021-07-23 19:11:53', '2021-07-23 19:11:53'),
(7, 'Milos', 'milos@milos.rs', '123123123', 'Zdravo', 'Zdravo, imam pitanje', '2021-07-23 19:12:52', '2021-07-23 19:12:52'),
(8, 'Milos', 'milos@milos.rs', '021414221', 'Poruka', 'Dobro.......', '2021-07-23 19:13:30', '2021-07-23 19:13:30'),
(9, 'Dusko', 'asds@asd.rs', '312', 'asdas', 'das2413trasd', '2021-07-23 19:13:47', '2021-07-23 19:13:47'),
(10, 'Dusko', 'admin@admin.rs', '12312', 'asdasdsad', 'd1231das', '2021-07-23 19:13:58', '2021-07-23 19:13:58'),
(11, 'Dusko', 'dusko@dusko.rs', '312', 'Savet', 'ok', '2021-07-23 19:14:17', '2021-07-23 19:14:17');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `naziv` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sadrzaj` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `slika` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kategorija` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `na_stanju` int(11) NOT NULL,
  `cena` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `created_at`, `updated_at`, `naziv`, `sadrzaj`, `slika`, `kategorija`, `na_stanju`, `cena`) VALUES
(1, '2021-07-23 13:16:12', '2021-07-23 13:32:12', 'Dres Mancester Junajteda za sezonu 2020/2021', '- Regular fit\r\n\r\n- AEROREADY tehnologija - upija znoj i brzo se suši\r\n\r\n- mekana i udobna tkanina\r\n\r\nSastav: 100% reciklirani poliester jacquard\r\n\r\nLicencirani originalni artikal', 'mancester.jpeg', 'dres', 5, 4899),
(2, '2021-07-23 13:34:52', '2021-07-23 18:35:35', 'Dres Fiorentine za sezonu 2020/2021', 'Radi se ponovo o ljubičastoj domaćoj te bijeloj gostujućoj garnituri, a njihovi dresovi bit će jedni od najjednostavnijih u Seriji A naredne sezone.', 'dres2.jpeg', 'dres', 12, 3999),
(3, '2021-07-23 18:09:32', '2021-07-23 18:09:32', 'Puma beli dres Srbije za SP u Rusiji', 'Originalni Puma beli dres Srbije u kojem su Orlovi nastupali na Svetskom prvenstvu u Rusiji 2018 i u kvalifikacijama za EP.', '2018-beli-dres-1.jpg', 'dres', 9, 3999),
(4, '2021-07-23 18:12:46', '2021-07-23 18:12:46', 'Šal', 'Navijački šal', 'sal.jpeg', 'Šal', 2, 489),
(5, '2021-07-23 18:16:58', '2021-07-23 18:17:53', 'Dres FK Zemun', 'Dres Fudbalskog kluba Zemun', 'zemun.jpg', 'dres', 10, 2790),
(6, '2021-07-23 18:21:05', '2021-07-23 18:21:05', 'LOPTA PUMA LA LIGA 2019/2020', 'LOPTA PUMA LA LIGA 2019/2020', 'lopta2.jpeg', 'lopta', 3, 8000),
(7, '2021-07-23 18:25:51', '2021-07-23 18:26:43', 'Lopta Premier lige', 'Lopta je sastavljena od svega četiri ploče, osam manje nego ranije što bi navodno trebalo da smanji „ukočenost“ površine lopte.', 'lopta1.jpg', 'lopta', 4, 2199),
(8, '2021-07-23 18:29:30', '2021-07-23 18:29:30', 'KOPACKE-PREDATOR 20.3', 'adidas PREDATOR 20.3 FG su izuzetno kvalitetne kopačke za fudbal. Inovativan dizajn spojen je sa sportskom funkcionalnošću. Poluduboki rez, osim što dodatno štiti zglobove, pruža lagano obuvanje i izuvanje.', 'EE9555.jpg', 'kopačke', 3, 7890),
(9, '2021-07-23 18:35:45', '2021-07-23 18:38:48', 'TS KOPACKE PREDATOR 19.1', 'Kopačke za čvrsto tlo', 'kop.jpg', 'kopačke', 6, 26399),
(10, '2021-07-23 18:42:13', '2021-07-23 18:42:13', 'KOPACKE JR VAPOR 13', 'KOPACKE JR VAPOR 13', 'at8161-801.jpg', 'kopačke', 15, 8945),
(11, '2021-07-23 18:44:05', '2021-07-23 18:44:05', 'KOPACKE-VAPOR 13 ELITE', 'Nike Mercurial Vapor 13 Elite MDS FG muške kopačke za fudbal će vam omogućiti brzinu dok igrate vašu omiljenu igru. Pletena Flyknit konstrukcija se obavija oko vašeg stopala tako da ćete se u njima osjećati kao u svojoj koži.', 'CJ1295-703_800_800px.jpg', 'kopačke', 1, 9999),
(12, '2021-07-23 18:57:07', '2021-07-23 18:57:07', 'TS KOPACKE SUPERFLY 8 PRO FG', 'TS KOPACKE SUPERFLY 8 PRO FG', 'ads.jpg', 'kopačke', 4, 13463),
(13, '2021-07-23 18:59:42', '2021-07-23 18:59:42', 'Dres Barselone 2017-2018', 'Dres Barselone 2017-2018', 'unnamed.jpg', 'dres', 2, 2000),
(14, '2021-07-23 19:04:59', '2021-07-23 19:52:05', 'adidas REAL H JSY', 'adidas REAL H JSY, muški dres za fudbal, bela', 'dw4433_app_photo_front-center_white.jpg', 'dres', 1, 6480),
(15, '2021-07-23 19:06:56', '2021-07-23 19:06:56', 'FC Bayern München Adidas Home dres', 'FC Bayern München Adidas Home dres', 'download.jpg', 'dres', 1, 11999);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `two_factor_secret` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `two_factor_recovery_codes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `two_factor_secret`, `two_factor_recovery_codes`, `remember_token`, `created_at`, `updated_at`, `type`) VALUES
(2, 'Editor', 'editor@editor.rs', NULL, '$2y$10$C2KOotC1ceN0eAZ4T07MaOzqgu10Bwx4aa3Ds2oan8LKqiqWhU24K', NULL, NULL, NULL, '2021-07-23 18:35:07', '2021-07-23 18:35:07', 'editor'),
(3, 'Marko', 'marko@marko.rs', NULL, '$2y$10$E6LCKyaPUlTZp9bHSjLDtepwmQ/fjEncvafMV2h/RYpQr1bribuM2', NULL, NULL, NULL, '2021-07-23 19:15:12', '2021-07-23 19:15:12', 'registered'),
(4, 'Milos Milosevic', 'milos@milos.rs', NULL, '$2y$10$S2oid2vyGVQgyLfPQK/Ei.FzuGA1e0jVAoSChLEq66A2DBQ/z1e1W', NULL, NULL, NULL, '2021-07-23 19:21:10', '2021-07-23 19:21:10', 'registered'),
(5, 'Petar', 'petar@petar.rs', NULL, '$2y$10$TC4oJSqtpQzzVM8BBawB9eMSxRuzyHD7/8SBpc9/JIu4sv0h7vXvG', NULL, NULL, NULL, '2021-07-23 19:26:04', '2021-07-23 19:26:04', 'registered'),
(6, 'Milica', 'milica@milica.rs', NULL, '$2y$10$W6nPgEuc0LysE8vhdG.Wfextj4mp8ajOzkfdNc8CveBTfVXQYrTJu', NULL, NULL, NULL, '2021-07-23 19:29:07', '2021-07-23 19:29:07', 'registered'),
(7, 'Душко Радоњић', 'admin@admin.rs', NULL, '$2y$10$k13.k3ZrF7WrN6SKKpjzk.feQi91i6HqbtdG7qFiBlMj6LS/jLL36', NULL, NULL, NULL, '2021-07-23 20:09:23', '2021-07-23 20:09:23', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `komentaris`
--
ALTER TABLE `komentaris`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `korpas`
--
ALTER TABLE `korpas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `narudzbinas`
--
ALTER TABLE `narudzbinas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `porukas`
--
ALTER TABLE `porukas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `komentaris`
--
ALTER TABLE `komentaris`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `korpas`
--
ALTER TABLE `korpas`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `narudzbinas`
--
ALTER TABLE `narudzbinas`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `porukas`
--
ALTER TABLE `porukas`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
