

<?php $__env->startSection('content'); ?>
<h2>Sve poruke</h2>
        <div class="table-responsive">
        <?php if(Session::has('success_msg')): ?>
            <div class="alert alert-success"><?php echo e(Session::get('success_msg')); ?></div>
        <?php endif; ?>
        <table class="table table-striped table-sm">
            <thead>
                <tr>
                    <th>Ime</th>
                    <th>Email</th>
                    <th>Subject</th>
                    <th>Poruka</th>
                    <th>Datum kreiranja</th>
                    <th>Opcije</th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $poruke; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($p->ime); ?></td>
                    <td><?php echo e($p->email); ?></td>
                    <td><?php echo e($p->subject); ?> din</td>
                    <td><?php echo e($p->poruka); ?></td>
                    <td><?php echo e($p->created_at); ?></td>

                    <td>
                    <a href="<?php echo e(route('poruke.obrisi', $p->id)); ?>" class="btn btn-danger" onclick="return confirm('Are you sure to delete?')">Obrisi</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fudbalski_klub\resources\views/admin/poruke.blade.php ENDPATH**/ ?>