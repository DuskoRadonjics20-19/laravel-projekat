

<?php $__env->startSection('content'); ?>

    <div class="container">
        <section class="mb-5 mt-5">
            <a href="<?php echo e(route('products.index')); ?>" class="btn btn-danger btn-lg pl-6"> Nazad</a>
            <div class="row">
                <div class="col-md-5 mb-4 mb-md-0">
                    <img src="<?php echo e(asset('storage/slike/' . $product->slika)); ?>  " width="450px" height="450px" alt=""> 
                </div>
                <div class="col-md-7">
                    <h3 class="mb-5"><?php echo e($product->naziv); ?></h3>
                    <p><strong>Kategorija:</strong> <?php echo e($product->kategorija); ?></p>
                    <p><strong>Cena:</strong> <?php echo e($product->cena); ?></p>
                    <strong>Opis:</strong>
                    <p class="mt-2"><?php echo e($product->sadrzaj); ?></p>
                    <hr>
                    <form action="<?php echo e(url('dodaj-u-korpu')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                        <input name="kolicina" type="hidden" value="1" class="span1" style="width: 60px; height:50px; " required>
                        <button type="submit" class="btn btn-primary btn-md mr-1 mb-2">Dodaj u korpu</button>
                    </form>
                </div>
            </div>
        </section>
    </div>
    <div class="container">
            <form method="POST" enctype="multipart/form-data" action="<?php echo e(route('dodaj-komentar')); ?>" >
            <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="form-group">
                        <label class="control-label col-sm-2" >Unesi komentar:</label>
                        <input type="hidden" name="products_id" value="<?php echo e($product->id); ?>">
                        <textarea type="text" name="komentar"  class="form-control mb-2"></textarea>
                    </div>
                    <div class="col-md-12">
                        <button type="submit" class="btn btn-success">Posalji komentar</button>
                    </div>
                </div>
            </form>
        <h4 class="mt-2">Svi komentari:</h4>
        <hr>
        <?php $__currentLoopData = $komentari; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($k->created_at); ?><br>
            <strong><?php echo e($k->komentar); ?></strong><br>
            <?php echo e($k->name); ?> 
        <hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fudbalski_klub\resources\views/products/detaljnije.blade.php ENDPATH**/ ?>