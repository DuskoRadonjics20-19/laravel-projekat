

<?php $__env->startSection('content'); ?>
    <h2>Spisak svih proizvoda</h2>
        <div class="table-responsive">
			<a href="<?php echo e(route('products.add')); ?>" class="btn btn-primary">Dodaj novi prozivod</a>
            <?php if(Session::has('success_msg')): ?>
            <div class="alert alert-success"><?php echo e(Session::get('success_msg')); ?></div>
        <?php endif; ?>
        <table class="table table-striped table-sm">
            <thead>
                <tr>
                    <th>Naziv</th>
                    <th>Kategorija</th>
                    <th>Na stanju</th>
                    <th>Cena</th>
                    <th>Datum dodavanja</th>
                    <th>Slika proizvoda</th>
                    <th>Opcije</th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($product->naziv); ?></td>
                    <td><?php echo e($product->kategorija); ?></td>
                    <td><?php echo e($product->na_stanju); ?></td>
                    <td><?php echo e($product->cena); ?> din</td>
                    <td><?php echo e($product->created_at); ?></i><br/></td>
                    </td>
                    <td><img src="<?php echo e(asset('storage/slike/' . $product->slika)); ?>  " width="120px" height="100px" alt=""></td>
                    <td><a href="<?php echo e(route('products.edit', $product->id)); ?>" class="btn btn-warning">Izmeni</a>
                    <a href="<?php echo e(route('products.delete', $product->id)); ?>" class="btn btn-danger" onclick="return confirm('Are you sure to delete?')">Obrisi</a>
                    
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fudbalski_klub\resources\views/admin/products.blade.php ENDPATH**/ ?>