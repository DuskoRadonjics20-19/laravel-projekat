

<?php $__env->startSection('content'); ?>
    <h2>Spisak svih narudzbi</h2>
        <div class="table-responsive">
        <?php if(Session::has('success_msg')): ?>
            <div class="alert alert-success"><?php echo e(Session::get('success_msg')); ?></div>
        <?php endif; ?>
        <table class="table table-striped table-sm">
            <thead>
                <tr>
                    <th>Ime</th>
                    <th>Naziv proizvoda</th>
                    <th>Cena</th>
                    <th>Kolicina</th>
                    <th>Datum kreiranja</th>
                    <th>Slika proizvoda</th>
                    <th>Opcije</th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $narudzbine; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($n->name); ?></td>
                    <td><?php echo e($n->naziv); ?></td>
                    <td><?php echo e($n->cena); ?> din</td>
                    <td><?php echo e($n->kolicina); ?></td>
                    <td><?php echo e($n->created_at); ?></td>
                    <td><img src="<?php echo e(asset('storage/slike/' . $n->slika)); ?>  " width="120px" height="100px" alt=""></td>

                    <td>
                    <a href="<?php echo e(route('narudzbine.obrisi', $n->id)); ?>" class="btn btn-danger" onclick="return confirm('Are you sure to delete?')">Obrisi</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fudbalski_klub\resources\views/admin/narudzbine.blade.php ENDPATH**/ ?>