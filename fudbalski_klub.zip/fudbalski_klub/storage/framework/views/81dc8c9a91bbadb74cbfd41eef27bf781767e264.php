

<?php $__env->startSection('content'); ?>
    <main class="mt-5 pt-4 mb-5">
        <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-12 col-md-offset-1">
                <?php if(Session::has('success_message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session::get('success_message')); ?>

                    </div>
                <?php endif; ?>
                <table class="table table-hover">
                    <thead>
                        <tr>  
                            <th>Proizvod</th>
                            <th>Količina</th>
                            <th class="text-center">Cena</th>
                            <th class="text-center">Naruči</th>
                            <th class="text-center">Obriši</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="col-sm-8 col-md-6">
                                <img src="<?php echo e(asset('storage/slike/' . $p->slika)); ?>  " width="50px" height="50px"  style="width: 72px; height: 72px;">
                                    <h4><?php echo e($p->naziv); ?></h4>
                            </td>
                            <td class="col-sm-1 col-md-1">
                                <input type="" class="form-control" value="<?php echo e($p->kolicina); ?>">
                            </td>
                            <td class="col-sm-1 col-md-1 text-center"><strong><?php echo e($p->cena); ?>.00 din</strong></td>
                            <td class="col-sm-1 col-md-1 text-center">
                                <form action="<?php echo e(url('kupi')); ?>" method="post" enctype="multipart/form-data">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" name="products_id" value="<?php echo e($p->products_id); ?>">
                                    <input type="hidden" name="kolicina" value="<?php echo e($p->kolicina); ?>">
                                    <input type="hidden" name="cena" value="<?php echo e($p->cena); ?>">

                                    <button class="btn btn-success btn-md my-0 p" type="submit">Naruči
                                        <i class="fas fa-shopping-cart ml-1"></i>
                                    </button>
                                </form>
                            </td>
                            <td class="col-sm-1 col-md-1">
                                <a href="<?php echo e(route('korpa.obrisi', $p->id)); ?>" class="btn btn-danger" onclick="return confirm('Are you sure to delete?')">Obriši</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fudbalski_klub\resources\views/korpa.blade.php ENDPATH**/ ?>