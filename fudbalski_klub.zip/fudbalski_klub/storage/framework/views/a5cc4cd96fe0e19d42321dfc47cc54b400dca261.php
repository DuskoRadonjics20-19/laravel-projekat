<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Fudbalski klub-Zemun</title>

	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

</head>
<body>
  <header class="p-3 bg-dark text-white">
    <div class="container">
      <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
        
        <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
          <li><a class="nav-link text-white" href="<?php echo e(route('products.index')); ?>">Početna</a></li>
          <li><a href="<?php echo e(route('products.onama')); ?>" class="nav-link px-2 text-white">O nama</a></li>
          <li><a href="<?php echo e(route('products.kontakt')); ?>" class="nav-link px-2 text-white">Kontakt</a></li>
        </ul>
        <div class="text-end">
        <?php if(auth()->guard()->check()): ?>
            <a class="btn btn-warning me-5" href="<?php echo e(route('korpa')); ?>">Korpa</a>
        <?php endif; ?>
        <?php if(auth()->guard()->guest()): ?>
          <a class="btn btn-outline-light me-2" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
          <?php if(Route::has('register')): ?>
          <a class="btn btn-warning" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
          <?php endif; ?>
          <?php else: ?>
        </div>
        <div class="dropdown text-end">
          <a href="#" class="d-block link-dark text-decoration-none dropdown-toggle text-white" id="dropdownUser1" data-bs-toggle="dropdown" aria-expanded="false">
        <?php echo e(Auth::user()->name); ?>

          </a>
          <ul class="dropdown-menu text-small" aria-labelledby="dropdownUser1">
          <li class="dropdown-item"><a class="nav-link text-dark" href="<?php echo e(route('profil')); ?>"><?php echo e(__('Profil/Narudzbine')); ?></a></li>
            <li><hr class="dropdown-divider"></li>
            <li class="dropdown-item">
                <a class="nav-link text-dark" href="<?php echo e(route('logout')); ?>"
                onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();">
                <?php echo e(__('Logout')); ?>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                </a>
            </li>
            <?php endif; ?>
          </ul>
        </div>
      </div>
    </div>
  </header>
    <main style="margin-bottom:50px;">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
</body>
</html><?php /**PATH C:\xampp\htdocs\fudbalski_klub\resources\views/layouts/app.blade.php ENDPATH**/ ?>