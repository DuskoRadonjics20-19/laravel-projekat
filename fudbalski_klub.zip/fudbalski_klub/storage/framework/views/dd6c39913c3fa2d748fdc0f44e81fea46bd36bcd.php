
<?php $__env->startSection('content'); ?>

<main class="mt-5 pt-4 mb-5">
        <div class="container">
        <div class="row">
        <?php $__currentLoopData = $name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="d-flex flex-column align-items-center text-center p-3 py-5">
                  
                <h2 class="font-weight-bold"><strong>  <?php echo e($n->name); ?></h2><span class="text-black-50"><?php echo e($n->email); ?></span><span> </span></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-sm-12 col-md-12 col-md-offset-1">
            
                <?php if(Session::has('success_message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session::get('success_message')); ?>

                    </div>
                <?php endif; ?>
            
                    <h3><strong>Narudzbine</strong></h3>
               
                <table class="table table-hover">
                    <thead>
                        <tr>  
                            <th>Slika proizvoda</th>
                            <th>Naziv</th>
                            <th>Kolicina</th>
                            <th>Datum narudzbe</th>
                            <th>Cena</th> 
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $narudzbina; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><img src="<?php echo e(asset('storage/slike/' . $n->slika)); ?>  " width="50px" height="50px" alt=""></td>
                            <td><?php echo e($n->naziv); ?></td>
                            <td><?php echo e($n->kolicina); ?></td>
                            <td><?php echo e($n->created_at); ?></td>
                            <td><?php echo e($n->cena); ?>.00 din</td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fudbalski_klub\resources\views/profil.blade.php ENDPATH**/ ?>