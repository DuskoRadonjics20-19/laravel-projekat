<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Fudbalski klub-Zemun</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
  </head>

<body>
  <header class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow">
    <a class="navbar-brand col-md-3 col-lg-2 me-0 px-3" href="#">Fudbalski klub - Zemun</a>
    <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="navbar-nav">
      <div class="nav-item text-nowrap">
                
                <a class="d-flex align-items-center nav-link dropdown-toggle dropdown-toggle-nocaret  me-5" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <div class="user-info ps-3">
                        <p class="text-white h4"><?php echo e(Auth::user()->name); ?></p>
                        <p class="text-white h6 ms-6"><?php echo e(Auth::user()->type); ?></p>

                        </div>
                    </a>
                    <ul class="dropdown-menu dropdown-menu">
                        <li>
                            <div class="dropdown-divider mb-0"></div>
                        </li>
                        <li><a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();">
                            <?php echo e(__('Logout')); ?>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
      </div>
    </div>
  </header>

  <div class="container-fluid">
    <div class="row">
      <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
        <div class="position-sticky pt-3">
          <ul class="nav flex-column">
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="<?php echo e(route('admin.admin')); ?>">Dashboard</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('admin.products')); ?>">Proizvodi</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('admin.users')); ?>">Korisnici</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('admin.narudzbine')); ?>">Narudžbine</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('admin.poruke')); ?>">Poruke</a>
            </li>
           
          </ul>
          
        </div>
      </nav>

      <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
          <h1 class="h2">Dashboard</h1>
        </div>
        <?php echo $__env->yieldContent('content'); ?>

      </main>
    </div>
  </div>


<?php /**PATH C:\xampp\htdocs\fudbalski_klub\resources\views/layouts/app-dashboard.blade.php ENDPATH**/ ?>