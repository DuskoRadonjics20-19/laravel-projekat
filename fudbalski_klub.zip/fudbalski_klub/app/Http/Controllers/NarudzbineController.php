<?php

namespace App\Http\Controllers;

use App\Models\Narudzbina;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Session;

class NarudzbineController extends Controller
{
    public function kupi(Request $request){
        if($request->isMethod('post')){
            $data = $request->all();

            $narudzbina = new Narudzbina;
            $narudzbina->products_id = $data['products_id'];
            $narudzbina->kolicina = $data['kolicina'];
            $narudzbina->cena = $data['cena'];
            $narudzbina->user_id=$request->user()->id;
            $narudzbina->save();
            
            $message = "Uspešno ste narucili ovaj proizvod!";
                session::flash('success_message',$message);

            return redirect()->back();
        }
    }
    public function narudzbine(Request $request){

        $narudzbine = DB::table('products')
        ->select('narudzbinas.user_id','narudzbinas.products_id','narudzbinas.kolicina','narudzbinas.created_at','products.id','narudzbinas.id','products.slika','products.naziv','products.cena','narudzbinas.cena','users.name')
        ->join('narudzbinas','products.id','=','narudzbinas.products_id')
        ->join('users', 'users.id', '=', 'narudzbinas.user_id')
        ->get();

        return view('admin.narudzbine', ['narudzbine' => $narudzbine]);
    }
    public function obrisi($id,Request $request){

        $p = Narudzbina::find($id);
        if($request->user()->cannot('delete',$p)){
            abort(403);
        }
        $product = DB::table('narudzbinas')->where('id',$id)->delete();
        
        Session::flash('success_msg', 'Obrisali ste narudzbinu!');
        return redirect()->route('admin.narudzbine');
    }
}