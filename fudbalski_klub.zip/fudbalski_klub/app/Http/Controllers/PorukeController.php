<?php

namespace App\Http\Controllers;

use App\Models\Poruka;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Session;

class PorukeController extends Controller
{
    public function poruka(Request $request){
        if($request->isMethod('POST')){
            $podaci = $request->all();
            
            $poruka = new Poruka;
            $poruka->ime = $podaci['ime'];
            $poruka->telefon = $podaci['telefon'];
            $poruka->email = $podaci['email'];
            $poruka->subject = $podaci['subject'];
            $poruka->poruka = $podaci['poruka'];
            $poruka->save();
            
            $message = "Uspešno ste poslali poruku!";
                session::flash('success_message',$message);

            return redirect()->back();
        }
    }
    public function sveporuke(Request $request){

        $poruke = DB::table('porukas')->get();

        return view('admin.poruke', ['poruke' => $poruke]);
        }
    public function obrisi($id,Request $request){
        $p = Poruka::find($id);
			if($request->user()->cannot('delete',$p)){
				abort(403);
			}
        $poruka = DB::table('porukas')->where('id',$id)->delete();
        
        Session::flash('success_msg', 'Poruka uspesno izbrisana!');

        return redirect()->route('admin.poruke');
    }
    public function kontakt(Request $request){
        return view('kontakt');
    }
}
