<?php

namespace App\Http\Controllers;

use App\Models\Korpa;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Session;

class KorpaController extends Controller
{
    public function DodajUKorpu(Request $request){
        if($request->isMethod('post')){
            $podaci = $request->all();
        
            $korpa = new Korpa;
            $korpa->products_id = $podaci['product_id'];
            $korpa->kolicina = $podaci['kolicina'];
            $korpa->user_id=$request->user()->id;
            $korpa->save();

            $message = "Uspešno ste dodali proizvod u korpu!";
                session::flash('success_message',$message);

            return redirect()->back();
        }
    }
    public function korpa(Request $request){
        $user_id=$request->user()->id;

        $product = DB::table('korpas')
        ->select('korpas.id','korpas.user_id','korpas.products_id','korpas.kolicina','korpas.created_at','products.slika','products.naziv','products.cena','users.name')
        ->join('users','korpas.user_id','=','users.id')
        ->join('products','korpas.products_id','=','products.id')
        ->where('users.id',$user_id)
        ->get();
        return view('korpa',['product' => $product]);

    }
    public function obrisi($id,Request $request){

        $p = Korpa::find($id);
        if($request->user()->cannot('delete',$p)){
            abort(403);
        }
        $kopra = DB::table('korpas')->where('id',$id)->delete();
        
        Session::flash('success_msg', 'Proizvod uspesno izbrisan iz korpe!');

        return redirect()->route('korpa');
    }
}