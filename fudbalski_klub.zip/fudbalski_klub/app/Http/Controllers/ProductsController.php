<?php

namespace App\Http\Controllers;
use App\Models\Product;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Session;

class ProductsController extends Controller
{
    public function index(Request $request){
        $products = Product::paginate(9);

        if($request->has('q')){
            $q = $request->get('q');
            $products = Product::where('naziv','LIKE',"%$q%")->orWhere('sadrzaj','LIKE',"%$q%")->paginate(9);
        } else{
            $products = Product::paginate(9);
        }

        return view('products.index', ['products' => $products]);
    }
    public function detaljnije($id){
        $product = Product::find($id);

		$komentari = DB::table('products')
		->join('komentaris','products.id','=','komentaris.products_id')
		->join('users', 'users.id', '=', 'komentaris.user_id')
		->where('products.id',$id)->orderBy('komentaris.id','desc')
		->get();

        return view('products.detaljnije', ['product' => $product,'komentari' => $komentari]);	
    }
    public function proizvodi(Request $request){
		$products = Product::orderBy('naziv','asc')->get();

        return view('admin.products', ['products' => $products]);
        }
    public function add(Request $request){
		return view('products.add');
	}
	public function insert(Request $request){
		$this->validate($request, [
			'naziv' => 'required',
			'sadrzaj' => 'required',
			'kategorija' => 'required',
			'na_stanju' => 'required',
			'cena' => 'required',
		]);
		if($request->file('slika')){

			$slika = $request->file('slika')->getClientOriginalName();
			$request->file('slika')->storeAs('public/slike' ,$slika);

			$product = new Product;
			$podaci = $request->all();
            
            $product->naziv = $podaci['naziv'];
            $product->sadrzaj = $podaci['sadrzaj'];
            $product->kategorija = $podaci['kategorija'];
            $product->na_stanju = $podaci['na_stanju'];
            $product->cena = $podaci['cena'];
			$product->slika = $slika;

            $product->save();
			Session::flash('success_msg', 'Proizvod je dodat uspesno!');

			return redirect()->route('admin.products');
		}
		Session::flash('error', 'Sve je obavezno popuniti!');
		return redirect()->route('products.add');
	}
	public function edit($id,Request $request){

		$product = Product::find($id);
		if($request->user()->cannot('update',$product)){
			abort(403);
		}
		return view('products.edit', ['product' => $product]);
	}
	
	public function update($id, Request $request){

		$product = Product::find($id);
		if($request->user()->cannot('update',$product)){
			abort(403);
		}
		$this->validate($request, [
			'naziv' => 'required',
			'sadrzaj' => 'required',
			'kategorija' => 'required',
			'na_stanju' => 'required',
			'cena' => 'required',
		]);
		$podaci = $request->all();
	 
		if($request->file('slika')){
			$podaci = $request->all();

			$slika = $request->file('slika')->getClientOriginalName();
			$request->file('slika')->storeAs('public/slike' ,$slika);
			$podaci['slika'] = "$slika";

			Product::find($id)->update($podaci);
		}
		
		Product::find($id)->update($podaci);

		Session::flash('success_msg', 'Uspesno ste izmenili proizvod!');
		return redirect()->route('admin.products');
	}
	public function delete($id,Request $request){

		$product = Product::find($id);
		if($request->user()->cannot('delete',$product)){
			abort(403);
		}
		$post = DB::table('products')->where('id',$id)->delete();

		Session::flash('success_msg', 'Uspesno ste izbrisali proizvod!');
		return redirect()->route('admin.products');
	}
	public function onama(Request $request){
        return view('onama');
    }
	public function grafik(Request $request){
        return view('admin.admin');
    }
}