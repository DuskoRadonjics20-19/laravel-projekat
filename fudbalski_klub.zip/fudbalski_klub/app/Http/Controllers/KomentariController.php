<?php

namespace App\Http\Controllers;

use App\Models\Komentari;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Session;

class KomentariController extends Controller
{
    public function komentar(Request $request){
        $komentari = $request->komentar;
        $products_id = $request->products_id;

        $komentar = new Komentari;
        $komentar->user_id=$request->user()->id;
        $komentar->products_id = $products_id;
        $komentar->komentar = $komentari;
    
        $komentar->save();
        Session::flash('success_msg', 'Uspesno ste uneli komentar!');
        return redirect()->back();
    }
}
