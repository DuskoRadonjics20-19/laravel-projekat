<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Session;

class UserController extends Controller
{
    public function korisnici(Request $request){

        $korisnici = User::orderBy('name','asc')->get();

        return view('admin.users', ['korisnici' => $korisnici]);
    }
    public function obrisi($id,Request $request){
        $users = User::find($id);
            
        if($request->user()->cannot('delete',$users)){
            abort(403);
        }
        $user = DB::table('users')->where('id',$id)->delete();

        Session::flash('success_msg', 'Korisnik uspesno izbrisan!');
        return redirect()->route('admin.users');
    }
    public function profil(Request $request){

        $user_id=$request->user()->id;
        $name = DB::table('users')->where('users.id',$user_id)->get();

        $narudzbina = DB::table('narudzbinas')
        ->select('narudzbinas.user_id','narudzbinas.products_id','narudzbinas.kolicina','narudzbinas.created_at','products.id','narudzbinas.id','narudzbinas.cena','products.slika','products.naziv','users.name')
        ->join('users','narudzbinas.user_id','=','users.id')
        ->join('products','narudzbinas.products_id','=','products.id')
        ->where('users.id',$user_id)
        ->get();

        return view('profil',['narudzbina' => $narudzbina,'name' => $name]);
    }
}