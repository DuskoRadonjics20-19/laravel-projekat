<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'App\Http\Controllers\ProductsController@index')->name('products.index');
Route::get('/o-nama', 'App\Http\Controllers\ProductsController@onama')->name('products.onama');
Route::get('/kontakt', 'App\Http\Controllers\PorukeController@kontakt')->name('products.kontakt');
Route::get('/profil', 'App\Http\Controllers\UserController@profil')->name('profil')->middleware('auth');

Route::post('/poruka','App\Http\Controllers\PorukeController@poruka');

Route::get('/products/detaljnije/{id}', 'App\Http\Controllers\ProductsController@detaljnije')->name('products.detaljnije');
Route::post('/dodaj-u-korpu','App\Http\Controllers\KorpaController@DodajUKorpu')->middleware(['auth']);
Route::get('/korpa','App\Http\Controllers\KorpaController@korpa')->name('korpa')->middleware(['auth']); 
Route::get('/korpa/delete/{id}', 'App\Http\Controllers\KorpaController@obrisi')->name('korpa.obrisi')->middleware(['auth']);

Route::post('/kupi','App\Http\Controllers\NarudzbineController@kupi')->middleware(['auth']);

Route::post('/dodaj-komentar','App\Http\Controllers\KomentariController@komentar')->name('dodaj-komentar')->middleware('auth');

//admin panel
Route::get('/admin','App\Http\Controllers\ProductsController@grafik')->name('admin.admin')->middleware('can:viewAny,App\Models\Product');

Route::get('/admin/products','App\Http\Controllers\ProductsController@proizvodi')->name('admin.products')->middleware('can:viewAny,App\Models\Product');

Route::get('add','App\Http\Controllers\ProductsController@add')->name('products.add')->middleware('can:create,App\Models\Product');
Route::post('add','App\Http\Controllers\ProductsController@insert')->middleware('can:create,App\Models\Product');
Route::get('/products/edit/{id}', 'App\Http\Controllers\ProductsController@edit')->name('products.edit')->middleware('auth'); 
Route::post('/products/update/{id}', 'App\Http\Controllers\ProductsController@update')->name('products.update')->middleware('auth'); 
Route::get('/products/delete/{id}', 'App\Http\Controllers\ProductsController@delete')->name('products.delete')->middleware('auth');

Route::get('/admin/users','App\Http\Controllers\UserController@korisnici')->name('admin.users')->middleware('can:viewAny,App\Models\User');
Route::get('/users/delete/{id}', 'App\Http\Controllers\UserController@obrisi')->name('users.delete')->middleware(['auth']);

Route::get('/admin/narudzbine','App\Http\Controllers\NarudzbineController@narudzbine')->name('admin.narudzbine');
Route::get('/narudzbine/obrisi/{id}', 'App\Http\Controllers\NarudzbineController@obrisi')->name('narudzbine.obrisi')->middleware(['auth']); 

Route::get('/admin/poruke','App\Http\Controllers\PorukeController@sveporuke')->name('admin.poruke');
Route::get('/poruke/obrisi/{id}', 'App\Http\Controllers\PorukeController@obrisi')->name('poruke.obrisi')->middleware(['auth']); 