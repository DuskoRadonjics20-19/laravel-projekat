@extends('layouts.app-dashboard')

@section('content')
<h2>Sve poruke</h2>
        <div class="table-responsive">
        @if(Session::has('success_msg'))
            <div class="alert alert-success">{{ Session::get('success_msg') }}</div>
        @endif
        <table class="table table-striped table-sm">
            <thead>
                <tr>
                    <th>Ime</th>
                    <th>Email</th>
                    <th>Subject</th>
                    <th>Poruka</th>
                    <th>Datum kreiranja</th>
                    <th>Opcije</th>
                </tr>
            </thead>
            <tbody>
            @foreach($poruke as $p)
                <tr>
                    <td>{{$p->ime}}</td>
                    <td>{{$p->email}}</td>
                    <td>{{$p->subject}} din</td>
                    <td>{{$p->poruka}}</td>
                    <td>{{$p->created_at}}</td>

                    <td>
                    <a href="{{ route('poruke.obrisi', $p->id) }}" class="btn btn-danger" onclick="return confirm('Are you sure to delete?')">Obrisi</a>
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
@endsection