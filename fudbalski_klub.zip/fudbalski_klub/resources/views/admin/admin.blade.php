@extends('layouts.app-dashboard')

@section('content')

<?php  
 $connect = mysqli_connect("localhost", "root", "", "fudbalski_klub");  
 $query = "SELECT naziv, na_stanju FROM products GROUP BY naziv";  
 $result = mysqli_query($connect, $query);  
 ?>  
 <!DOCTYPE html>  
 <html>  
      <head>  
           <title>Najprodavanija kategorija</title>  
           <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>  
           <script type="text/javascript">  
           google.charts.load('current', {'packages':['corechart']});  
           google.charts.setOnLoadCallback(drawChart);  
           function drawChart()  
           {  
                var data = google.visualization.arrayToDataTable([  
                          ['Gender', 'Number'],  
                          <?php  
                          while($row = mysqli_fetch_array($result))  
                          {  
                               echo "['".$row["naziv"]."', ".$row["na_stanju"]."],";  
                          }  
                          ?>  
                     ]);  
                var options = {  
                      title: 'Procenat po kolicini proizvoda na stanju',  
                      //is3D:true,  
                     };  
            
                var chart = new google.visualization.PieChart(document.getElementById('piechart'));  
                chart.draw(data, options);  

           }  
           </script>  
           
      </head>  
      <body>  
      <div class="container-fluid">
          <div class="container">
               <br /><br />  
               
               <div class="table-light">  
                    <h3>Proizvodi po kolicini proizvoda na stanju</h3>  
                    <br />  
                    <div id="piechart" style="width: 900px; height: 700px;"></div>  
               </div> 
               
          </div>
     </body>  
 </html>  
    
@endsection