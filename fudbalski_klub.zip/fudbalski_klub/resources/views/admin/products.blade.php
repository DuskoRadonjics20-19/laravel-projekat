@extends('layouts.app-dashboard')

@section('content')
    <h2>Spisak svih proizvoda</h2>
        <div class="table-responsive">
			<a href="{{ route('products.add') }}" class="btn btn-primary">Dodaj novi prozivod</a>
            @if(Session::has('success_msg'))
            <div class="alert alert-success">{{ Session::get('success_msg') }}</div>
        @endif
        <table class="table table-striped table-sm">
            <thead>
                <tr>
                    <th>Naziv</th>
                    <th>Kategorija</th>
                    <th>Na stanju</th>
                    <th>Cena</th>
                    <th>Datum dodavanja</th>
                    <th>Slika proizvoda</th>
                    <th>Opcije</th>
                </tr>
            </thead>
            <tbody>
            @foreach($products as $product)
                <tr>
                    <td>{{$product->naziv}}</td>
                    <td>{{$product->kategorija}}</td>
                    <td>{{$product->na_stanju}}</td>
                    <td>{{$product->cena}} din</td>
                    <td>{{$product->created_at}}</i><br/></td>
                    </td>
                    <td><img src="{{asset('storage/slike/' . $product->slika)}}  " width="120px" height="100px" alt=""></td>
                    <td><a href="{{ route('products.edit', $product->id) }}" class="btn btn-warning">Izmeni</a>
                    <a href="{{ route('products.delete', $product->id) }}" class="btn btn-danger" onclick="return confirm('Are you sure to delete?')">Obrisi</a>
                    
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
@endsection