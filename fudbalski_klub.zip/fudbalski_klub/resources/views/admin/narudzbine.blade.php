@extends('layouts.app-dashboard')

@section('content')
    <h2>Spisak svih narudzbi</h2>
        <div class="table-responsive">
        @if(Session::has('success_msg'))
            <div class="alert alert-success">{{ Session::get('success_msg') }}</div>
        @endif
        <table class="table table-striped table-sm">
            <thead>
                <tr>
                    <th>Ime</th>
                    <th>Naziv proizvoda</th>
                    <th>Cena</th>
                    <th>Kolicina</th>
                    <th>Datum kreiranja</th>
                    <th>Slika proizvoda</th>
                    <th>Opcije</th>
                </tr>
            </thead>
            <tbody>
            @foreach($narudzbine as $n)
                <tr>
                    <td>{{$n->name}}</td>
                    <td>{{$n->naziv}}</td>
                    <td>{{$n->cena}} din</td>
                    <td>{{$n->kolicina}}</td>
                    <td>{{$n->created_at}}</td>
                    <td><img src="{{asset('storage/slike/' . $n->slika)}}  " width="120px" height="100px" alt=""></td>

                    <td>
                    <a href="{{ route('narudzbine.obrisi', $n->id) }}" class="btn btn-danger" onclick="return confirm('Are you sure to delete?')">Obrisi</a>
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
@endsection