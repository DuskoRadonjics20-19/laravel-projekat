@extends('layouts.app-dashboard')

@section('content')
    <h2>Spisak svih korisnika</h2>
        <div class="table-responsive">
        @if(Session::has('success_msg'))
            <div class="alert alert-success">{{ Session::get('success_msg') }}</div>
        @endif
        <table class="table table-striped table-sm">
            <thead>
                <tr>
                    <th>Ime</th>
                    <th>Email</th>
                    <th>Tip korisnika</th>
                    <th>Datum kreiranja</th>
                    <th>Opcije</th>
                </tr>
            </thead>
            <tbody>
            @foreach($korisnici as $k)
                <tr>
                    <td>{{$k->name}}</td>
                    <td>{{$k->email}}</td>
                    <td>{{$k->type}}</td>
                    <td>{{$k->created_at}}</td>
                    <td>
                    <a href="{{ route('users.delete', $k->id) }}" class="btn btn-danger" onclick="return confirm('Are you sure to delete?')">Obrisi</a>
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
@endsection