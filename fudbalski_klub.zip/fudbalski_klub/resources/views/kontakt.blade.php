@extends('layouts.app')
@section('content')
<div class="container contact-form">
            
            <form class="col-md-9 m-auto" action="{{ url('poruka') }}" method="post" enctype="multipart/form-data">
            @csrf
                @if(Session::has('success_message'))
                    <div class="alert alert-success">
                        {{ Session::get('success_message') }}
                    </div>
                @endif
                <h3>Pošaljite nam poruku</h3>
               <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <input type="text" name="ime" class="form-control" placeholder="Tvoje ime *" value="" />
                        </div>
                    </div>
                    <div class="col-md-6">

                        <div class="form-group ">
                            <input type="text" name="email" class="form-control" placeholder="Tvoj Email *" value="" />
                        </div>
                        </div>
                        <div class="form-group mt-3">
                            <input type="text" name="telefon" class="form-control" placeholder="Tvoj broj telefona *" value="" />
                        </div>
                        <div class="form-group mt-3">
                            <input type="text" name="subject" class="form-control" placeholder="Subject *" value="" />
                        </div>
                        <div class="col md-12 mt-3">
                        <div class="form-group">
                            <textarea name="poruka" class="form-control" placeholder="Tvoja Poruka *" style="width: 100%; height: 300px;"></textarea>
                        </div>
                    </div>
                        <div class="form-group mt-3">
                            <input type="submit" name="" class="btn btn-success" value="Posalji poruku" />
                        </div>
                    </div>
                  
                </div>
            </form>
</div>
@endsection