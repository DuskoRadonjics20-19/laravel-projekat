@extends('layouts.app-dashboard')

@section('content')
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Dodaj novi proizvod</h2> 
        </div>
        <a href="{{ route('admin.products') }}" class="btn btn-warning">Nazad na proizvode</a>
    </div>
</div>
<form action="{{ route('products.update', $product->id) }}" enctype="multipart/form-data" method="POST" class="form-horizontal">
    {{ csrf_field() }}
  
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 mt-3">
            <div class="form-group">
                <strong>Naziv:</strong>
                <input type="text" name="naziv" class="form-control"  value="{{ $product->naziv }}">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 mt-3">
            <div class="form-group">
                <strong>Sadrzaj:</strong>
                <textarea type="text" name="sadrzaj" class="form-control" style="height:250px">{{ $product->sadrzaj }}</textarea>
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 mt-3">
            <div class="form-group">
                <strong>Kateorija:</strong>
                <input type="text" name="kategorija" class="form-control" value="{{ $product->kategorija }}">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 mt-3">
            <div class="form-group">
                <strong>Na stanju:</strong>
                <input type="number" name="na_stanju" class="form-control" value="{{ $product->na_stanju }}">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 mt-3">
            <div class="form-group">
                <strong>Cena:</strong>
                <input type="number" name="cena" class="form-control" value="{{ $product->cena }}">
            </div>
        </div>
        <div class="form-group mt-3">
            <input type="file" name="slika" id="slika">
        </div>

        </div>
            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button type="submit" class="btn btn-primary">Update proizvod</button>
            </div>
        </div>
    </form>
@endsection