@extends('layouts.app-dashboard')

@section('content')
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Dodaj novi proizvod</h2> 
        </div>
        <a href="{{ route('admin.products') }}" class="btn btn-warning">Nazad na proizvode</a>
    </div>
</div>
<form method="POST" enctype="multipart/form-data" id="upload-image" action="{{ route('products.add') }}" >
    @csrf
  
     <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 mt-3">
            <div class="form-group">
                <strong>Naziv:</strong>
                <input type="text" name="naziv" class="form-control" placeholder="Unesi naziv proizvoda...">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 mt-3">
            <div class="form-group">
                <strong>Sadrzaj:</strong>
                <textarea type="text" name="sadrzaj" class="form-control" placeholder="Unesi sadrzaj..." style="height:250px"></textarea>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 mt-3">
            <div class="form-group">
                <strong>Kategorija:</strong>
                <input type="text" name="kategorija" class="form-control" placeholder="Unesi kategoriju...">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 mt-3">
            <div class="form-group">
                <strong>Na stanju:</strong>
                <input type="number" name="na_stanju" class="form-control" placeholder="Kolicina na stanju...">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 mt-3">
            <div class="form-group">
                <strong>Cena:</strong>
                <input type="number" name="cena" class="form-control" placeholder="Unesi cenu...">
            </div>
        </div>
        <div class="form-group mt-3">
            <input type="file" name="slika" id="slika">
        </div>
        @if(Session::has('error'))
            <div class="alert alert-danger">{{ Session::get('error') }}</div>
        @endif
        </div>
            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button type="submit" class="btn btn-primary">Unesi proizvod</button>
            </div>
        </div>
    </form>
@endsection
