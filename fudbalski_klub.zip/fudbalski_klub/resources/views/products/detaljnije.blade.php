@extends('layouts.app')

@section('content')

    <div class="container">
        <section class="mb-5 mt-5">
            <a href="{{ route('products.index') }}" class="btn btn-danger btn-lg pl-6"> Nazad</a>
            <div class="row">
                <div class="col-md-5 mb-4 mb-md-0">
                    <img src="{{asset('storage/slike/' . $product->slika)}}  " width="450px" height="450px" alt=""> 
                </div>
                <div class="col-md-7">
                    <h3 class="mb-5">{{ $product->naziv }}</h3>
                    <p><strong>Kategorija:</strong> {{ $product->kategorija }}</p>
                    <p><strong>Cena:</strong> {{ $product->cena }}</p>
                    <strong>Opis:</strong>
                    <p class="mt-2">{{ $product->sadrzaj }}</p>
                    <hr>
                    <form action="{{ url('dodaj-u-korpu') }}" method="post" enctype="multipart/form-data">
                        {{ csrf_field() }}
                        <input type="hidden" name="product_id" value="{{ $product->id }}">
                        <input name="kolicina" type="hidden" value="1" class="span1" style="width: 60px; height:50px; " required>
                        <button type="submit" class="btn btn-primary btn-md mr-1 mb-2">Dodaj u korpu</button>
                    </form>
                </div>
            </div>
        </section>
    </div>
    <div class="container">
            <form method="POST" enctype="multipart/form-data" action="{{ route('dodaj-komentar') }}" >
            @csrf
                <div class="row">
                    <div class="form-group">
                        <label class="control-label col-sm-2" >Unesi komentar:</label>
                        <input type="hidden" name="products_id" value="{{ $product->id }}">
                        <textarea type="text" name="komentar"  class="form-control mb-2"></textarea>
                    </div>
                    <div class="col-md-12">
                        <button type="submit" class="btn btn-success">Posalji komentar</button>
                    </div>
                </div>
            </form>
        <h4 class="mt-2">Svi komentari:</h4>
        <hr>
        @foreach($komentari as $k)
            {{$k->created_at}}<br>
            <strong>{{$k->komentar}}</strong><br>
            {{$k->name}} 
        <hr>
        @endforeach
    </div>
@endsection