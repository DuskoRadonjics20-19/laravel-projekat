@extends('layouts.app')
@section('content')
<main>

  <section class="py-5 text-center container">
  <nav class="navbar navbar-expand-lg mt-3 mb-5">

    <form action="{{ route('products.index') }}" method="get" role="search">
      <div class="input-group">
        <input type="text" class="form-control" style="width:400px;height:50px;margin-right:5px;"name="q" placeholder="Search">
        <span class="input-group-btn">
        <button class="btn btn-outline-success text-dark" type="submit" style="height:50px">Pretraga</button>
        </span>
      </div>
    </form>
    </nav>
  </section>

  <div class="album py-5 bg-light">
    <div class="container">
    <div class="row">
    @if(Session::has('success_message'))
          <div class="alert alert-success">
              {{ Session::get('success_message') }}
          </div>
      @endif
    @foreach($products as $product)
      <div class="row col-lg-4 col-md-6 mb-4">
        <div class="col">
          <div class="card shadow-sm">
          <a href="{{ route('products.detaljnije', $product->id) }}">
                <img src="{{asset('storage/slike/' . $product->slika)}}  " width="80%" height="250px" alt="" style="margin-left:40px">
              </a>

            <div class="card-body">
              <p class="card-text"><h4 class="card-title ms-4"><a class="text-decoration-none" href="{{ route('products.detaljnije', $product->id) }}">{{$product->naziv}}</a></h4>
                      <h5 style="margin-left:30px">Cena: {{$product->cena}}.00 din</h5></p>
              <div class="d-flex justify-content-between align-items-center">
                <form action="{{ url('dodaj-u-korpu') }}" method="post" enctype="multipart/form-data">
                        {{ csrf_field() }}
                      <input type="hidden" name="product_id" value="{{ $product->id }}">
                      <input name="kolicina" type="hidden" value="1">
                      <button style="width:250px;" type="submit" class="btn btn-success col-md-12 col-12 col-form-label  mt-3 ">Dodaj u korpu</button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
      @endforeach
      <nav class="d-flex justify-content-center wow fadeIn">
        <ul class="pagination pg-blue">
        {!! $products->appends(Request::all())->links() !!}
        </ul>
        </nav>
    </div>
    </div>
  </div>
</main>
@endsection