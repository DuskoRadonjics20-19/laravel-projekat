@extends('layouts.app')
@section('content')

<main class="mt-5 pt-4 mb-5">
        <div class="container">
        <div class="row">
        @foreach($name as $n)
                <div class="d-flex flex-column align-items-center text-center p-3 py-5">
                  
                <h2 class="font-weight-bold"><strong>  {{ $n->name }}</h2><span class="text-black-50">{{ $n->email }}</span><span> </span></div>
            @endforeach
            </div>
            <div class="col-sm-12 col-md-12 col-md-offset-1">
            
                @if(Session::has('success_message'))
                    <div class="alert alert-success">
                        {{ Session::get('success_message') }}
                    </div>
                @endif
            
                    <h3><strong>Narudzbine</strong></h3>
               
                <table class="table table-hover">
                    <thead>
                        <tr>  
                            <th>Slika proizvoda</th>
                            <th>Naziv</th>
                            <th>Kolicina</th>
                            <th>Datum narudzbe</th>
                            <th>Cena</th> 
                        </tr>
                    </thead>
                    <tbody>
                    @foreach($narudzbina as $n)
                        <tr>
                            <td><img src="{{asset('storage/slike/' . $n->slika)}}  " width="50px" height="50px" alt=""></td>
                            <td>{{$n->naziv}}</td>
                            <td>{{$n->kolicina}}</td>
                            <td>{{$n->created_at}}</td>
                            <td>{{$n->cena}}.00 din</td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    </main>
@endsection