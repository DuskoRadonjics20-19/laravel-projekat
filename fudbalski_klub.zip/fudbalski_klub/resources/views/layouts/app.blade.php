<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Fudbalski klub-Zemun</title>

	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

</head>
<body>
  <header class="p-3 bg-dark text-white">
    <div class="container">
      <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
        
        <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
          <li><a class="nav-link text-white" href="{{ route('products.index') }}">Početna</a></li>
          <li><a href="{{route('products.onama')}}" class="nav-link px-2 text-white">O nama</a></li>
          <li><a href="{{route('products.kontakt')}}" class="nav-link px-2 text-white">Kontakt</a></li>
        </ul>
        <div class="text-end">
        @auth
            <a class="btn btn-warning me-5" href="{{ route('korpa') }}">Korpa</a>
        @endauth
        @guest
          <a class="btn btn-outline-light me-2" href="{{ route('login') }}">{{ __('Login') }}</a>
          @if (Route::has('register'))
          <a class="btn btn-warning" href="{{ route('register') }}">{{ __('Register') }}</a>
          @endif
          @else
        </div>
        <div class="dropdown text-end">
          <a href="#" class="d-block link-dark text-decoration-none dropdown-toggle text-white" id="dropdownUser1" data-bs-toggle="dropdown" aria-expanded="false">
        {{ Auth::user()->name }}
          </a>
          <ul class="dropdown-menu text-small" aria-labelledby="dropdownUser1">
          <li class="dropdown-item"><a class="nav-link text-dark" href="{{ route('profil') }}">{{ __('Profil/Narudzbine') }}</a></li>
            <li><hr class="dropdown-divider"></li>
            <li class="dropdown-item">
                <a class="nav-link text-dark" href="{{ route('logout') }}"
                onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();">
                {{ __('Logout') }}
                    <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                        @csrf
                    </form>
                </a>
            </li>
            @endguest
          </ul>
        </div>
      </div>
    </div>
  </header>
    <main style="margin-bottom:50px;">
        @yield('content')
    </main>
</body>
</html>