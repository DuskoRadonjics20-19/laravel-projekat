@extends('layouts.app')
@section('content')

<div class="container mt-5">
    <h3>O nama</h3>
    <p><strong>FK Zemun</strong> je fudbalski klub. Osnovan je 1946. godine pod imenom Jedinstvo Zemun.
    FK Zemun igra na Gradskom stadionu koji može primiti do 12.000 gledatelja.
    Boje kluba su plava i zelena.</p>
    <h6>Na slici ispod se nalazi stadion FK Zemun</h6>
    <img src="{{asset('storage/slike/stadion.jpg')}}" width="100%" height="650px" alt="about" width="150px" class="mb-4">
   <p>Klub je osnovan po završetku Drugog svetskog rata, 1945. godine pod imenom FK Maksim Divnić Zemun,
    ali je nakon nekoliko odigranih utakmica promenio ime u FK Sremac Zemun. 1946. godine, na inicijativu
    Branka Pešića dolazi do spajanja FK Sremac i FK Sparta Zemun u FK Jedinstvo Zemun. Zbog loših rezultata
    tokom sesone 1968./69. dolazi do saradnje s farmaceutsko-hemijskom firmom "Galenika", koja je bila u ekspanziji.
    Kako je firma već posedovala fudbalski klub FK Galenika, odlučeno je 1969. godine da se FK Jedinstvo spoji s 
    FK Galenika i da preuzme ime.
    <p>Zbog Galenikinog prestanka finansiranja kluba, na sednici održanoj 1984. godine donešena je 
    odluka da se iz imena kluba ukloni njeno ime, te od 1985. godine klub nosi današnje ime FK Zemun.</p> 
    U sezoni 2007./08., FK Zemun je ušao u finale „Lav“ kupa Srbije, što je najveći klupski uspeh u državnom kupu.
    Finale Kupa FK Zemun je igrao protiv FK Partizana, te izgubio rezultatom 3:0. Međutim, FK Partizan osvojio je
    i prvenstvo Srbije, pa je FK Zemun stekao pravo igranja u prvom kolu kvalifikacija za Kup UEFA.
    Zbog nepovoljnog finansijskog stanja kluba, UEFA mu nije izdala dopuštenje za nastup u Kupu, pa je njegovo mesto zauzeo FK Borac iz Čačka.
    Iste sezone klub je ispao u treći razred nogometa u Srbiji.</p>
    <div class="row">
    <div class="col-md-6">
    <img src="{{asset('storage/slike/dres.jpg')}}" width="100%" height="450px" alt="about" width="150px" class="mb-4">
    </div>
    <div class="col-md-6">
    <img src="{{asset('storage/slike/mrkaic.jpg')}}" width="100%" height="450px" alt="about" width="150px" class="mb-4">
    </div>
    </div>
    <p>U sezoni 2008/09, FK Zemun je igrao u Srpskoj ligi-Beograd i osvojio prvo mesto, cime je usao u Prvu ligu Srbije.
    Medjutim u sezoni 2010/11. kao 16-plasirani tip ispao je u Srpsku ligu Beograd. U Srpskoj ligi je proveo cetiri sezone,
    ali je u sezoni 2014/15. zauzeo prvo mesto i vratio se u Prvu ligu Srbije.
    <p>Sezone 2016/17, FK Zemun osvaja drugo mesto u Prvoj ligi i nakon decenijske pauze ponovo igra Superligu Srbije.</p> </p>
</div>

@endsection